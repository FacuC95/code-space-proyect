package com.openbootcamp;

public class tarea {

    public static void main(String[] args) {

        int variable1 = 2;
        System.out.println("La variable número 1 es: " + variable1);

        long variable2 = 12;
        System.out.println("La variable número 2 es: " + variable2);

        double variable3 = 3.9d;
        System.out.println("La variable número 3 es: " + variable3);

        float variable4 = 5.92f;
        System.out.println("La variable número 4 es: " + variable4);

        boolean verdadero = true;
        boolean falso = false;
        String name = "Facundo";
        System.out.println("Mi nombre es Facundo");
        if (name == "Facundo"){
            System.out.println("Verdadero");
        }
        else {
            System.out.println("Falso");
        }



    }

}
